#ifndef DAEMON_H
#define DAEMON_H

void daemonize(void);

#endif // DAEMON_H
