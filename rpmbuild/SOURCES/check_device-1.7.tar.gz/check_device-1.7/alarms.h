#ifndef ALARMS_H
#define ALARMS_H

void check_and_alarm(void);

#endif // ALARMS_H
